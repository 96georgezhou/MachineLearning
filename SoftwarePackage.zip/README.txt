Data sets: 	Poker_Hand_Testing.csv
		Poker_Hand_Training.csv

To run the program, have source code file and data files in the same directory

Input: Testing and Training files

Output: Confusion Matrixes plot for 	Random Forest
					Random Forest with 3-fold validation
					Decision Tree
					Decision Tree with 3-fold validation
					3 Nearest Neighbors
					Support Vector Machine
					Support Vector Machine with linear kernel