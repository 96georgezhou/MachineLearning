import pandas
import seaborn
import numpy as np
import matplotlib.pyplot as plt

from sklearn import svm, datasets
from sklearn.svm import SVC
from sklearn.svm import LinearSVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
from sklearn.ensemble import RandomForestClassifier
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn import neighbors, datasets
from sklearn.model_selection import cross_val_predict

df = pandas.read_csv('Poker_Hand_Training.csv', sep=',')
pokerHands = []
ranks = []
class_names = [0,1,2,3,4,5,6,7,8,9]
for row in df.itertuples():
    pokerHand = row[1:-1]
    rank = row[-1]
    pokerHands.append(pokerHand)
    ranks.append(rank)
clf = tree.DecisionTreeClassifier(max_depth=10,min_samples_split=10)
clf = clf.fit(pokerHands, ranks)
testDf = pandas.read_csv('Poker_Hand_Testing.csv', sep=',')
testPokerHands = []
testRanks = []
for tRow in testDf.itertuples():
    testPokerHand = tRow[1:-1]
    testRank = tRow[-1]
    testPokerHands.append(testPokerHand)
    testRanks.append(testRank)

classifier = RandomForestClassifier(n_estimators=50, max_depth=20, random_state=0,min_samples_split=10)
classifier = classifier.fit(pokerHands,ranks)

#cnf_matrix = confusion_matrix(testRanks, cross_val_predict(classifier,testPokerHands,testRanks,cv=3))
cnf_matrix = confusion_matrix(testRanks, classifier.predict(testPokerHands))

df_cm = pandas.DataFrame(cnf_matrix, index = [i for i in "0123456789"],
                  columns = [i for i in "0123456789"])
plt.figure(figsize = (10,7))
seaborn.heatmap(df_cm, annot=True, fmt='d')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title('RandomForest')

classifier = RandomForestClassifier(n_estimators=50, max_depth=20, random_state=0,min_samples_split=10)
#classifier = classifier.fit(pokerHands,ranks)
#print(sum(a == b for a,b in zip(testRanks, classifier.predict(testPokerHands))))

cnf_matrix = confusion_matrix(testRanks, cross_val_predict(classifier,testPokerHands,testRanks,cv=3))
# cnf_matrix = confusion_matrix(testRanks, classifier.predict(testPokerHands))
#np.set_printoptions(precision=2)

df_cm = pandas.DataFrame(cnf_matrix, index = [i for i in "0123456789"],
                  columns = [i for i in "0123456789"])
plt.figure(figsize = (10,7))
seaborn.heatmap(df_cm, annot=True, fmt='d')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title('RandomForest 3 Fold Validation')

classifier = DecisionTreeClassifier(random_state=0,max_depth = 1000)
classifier = classifier.fit(pokerHands,ranks)
# print(sum(a == b for a,b in zip(testRanks, classifier.predict(testPokerHands))))
cnf_matrix = confusion_matrix(testRanks, classifier.predict(testPokerHands))
#cnf_matrix = confusion_matrix(testRanks, cross_val_predict(classifier,testPokerHands,testRanks,cv=3))

df_cm = pandas.DataFrame(cnf_matrix, index = [i for i in "0123456789"],
                  columns = [i for i in "0123456789"])
plt.figure(figsize = (10,7))
seaborn.heatmap(df_cm, annot=True, fmt='d')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title('DecisionTree')

classifier = DecisionTreeClassifier(random_state=0,max_depth = 1000)
# classifier = classifier.fit(pokerHands,ranks)
# print(sum(a == b for a,b in zip(testRanks, classifier.predict(testPokerHands))))

# cnf_matrix = confusion_matrix(testRanks, classifier.predict(testPokerHands))
cnf_matrix = confusion_matrix(testRanks, cross_val_predict(classifier,testPokerHands,testRanks,cv=3))

df_cm = pandas.DataFrame(cnf_matrix, index = [i for i in "0123456789"],
                  columns = [i for i in "0123456789"])
plt.figure(figsize = (10,7))
seaborn.heatmap(df_cm, annot=True, fmt='d')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title('DecisionTree 3 Fold Validation')

n_neighbors = 3
weights = 'distance'

classifier = neighbors.KNeighborsClassifier(n_neighbors, weights=weights)
classifier = classifier.fit(pokerHands,ranks)
#print(sum(a == b for a,b in zip(testRanks, classifier.predict(testPokerHands))))

cnf_matrix = confusion_matrix(testRanks, classifier.predict(testPokerHands))

df_cm = pandas.DataFrame(cnf_matrix, index = [i for i in "0123456789"],
                  columns = [i for i in "0123456789"])
plt.figure(figsize = (10,7))
seaborn.heatmap(df_cm, annot=True, fmt='d')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title('KNearestNeighbors')

classifier = svm.SVC(gamma= 0.1, kernel='rbf')
classifier = classifier.fit(pokerHands,ranks)

cnf_matrix = confusion_matrix(testRanks, classifier.predict(testPokerHands))

df_cm = pandas.DataFrame(cnf_matrix, index = [i for i in "0123456789"],
                  columns = [i for i in "0123456789"])
plt.figure(figsize = (10,7))
seaborn.heatmap(df_cm, annot=True, fmt='d')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title('SupportVectorMachine')

classifier = svm.LinearSVC()
classifier = classifier.fit(pokerHands,ranks)
LinearSVC(C=1.0, class_weight=None, dual=True, fit_intercept=True,
     intercept_scaling=1, loss='squared_hinge', max_iter=1000,
     multi_class='ovr', penalty='l2', random_state=None, tol=0.0001,
     verbose=0)

cnf_matrix = confusion_matrix(testRanks, classifier.predict(testPokerHands))

df_cm = pandas.DataFrame(cnf_matrix, index = [i for i in "0123456789"],
                  columns = [i for i in "0123456789"])
plt.figure(figsize = (10,7))
seaborn.heatmap(df_cm, annot=True, fmt='d')
plt.xlabel('Predicted label')
plt.ylabel('True label')
plt.title('LinearSupportVectorMachine')

plt.show()